package com.kogentix.connector

import org.apache.spark.SparkConf
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.Seconds
import org.apache.spark.streaming.kafka010._
import java.util.Properties
import java.io.FileInputStream
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe

object KafkaSpark {
  def getPropertiesMap(filaPath: String): Map[String, String] = {
    val prop = new Properties
    prop.load(new FileInputStream(filaPath))
    val propertyNames = prop.propertyNames
    var kVPair = scala.collection.mutable.Map[String, String]()
    while (propertyNames.hasMoreElements()) {
      val propertyName = String.valueOf(propertyNames.nextElement())
      val propertyVal = prop.getProperty(propertyName).trim
      kVPair += (propertyName -> propertyVal)
    }
    scala.collection.immutable.Map(kVPair.toSeq: _*)
  }

  def createSparkStreamingContext(conf: SparkConf, kafkaConsumerParamMap: Map[String, String], otherPropertiesMap: Map[String, String]): StreamingContext = {

    val batchDuration = otherPropertiesMap("batchDurationSec").toInt
    val ssc = new StreamingContext(conf, Seconds(batchDuration))
    ssc.checkpoint(otherPropertiesMap("checkPointDirectory"))

    // Get input stream from kafka
    val topicsSet = otherPropertiesMap("topicsToListen").split(",")
    val messages = KafkaUtils.createDirectStream[String, String](ssc, PreferConsistent, Subscribe[String, String](topicsSet, kafkaConsumerParamMap))

    //DO YOUR PROCESSING HERE
    //messages.map(record => (record.key, record.value))

    ssc
  }
  
  // spark-submit --class com.kogentix.connector.KafkaSpark <jarpath>  <consumer> <other>

  def main(args: Array[String]) {

    val Array(kafkaConsumerProperties, otherProperties) = args

    val kafkaConsumerParamMap = getPropertiesMap(kafkaConsumerProperties)
    val otherPropertiesMap = getPropertiesMap(otherProperties)

    val conf = new SparkConf().setAppName("Kafka topic Spark Consumer").setMaster("local") //we can change local to other
    conf.set("spark.streaming.stopGracefullyOnShutdown", "true")
    conf.set("spark.streaming.kafka.maxRetries", "1")

    // Create spark streaming context with checkpoint
    val ssc = StreamingContext.getOrCreate(otherPropertiesMap("checkPointDirectory"), () => { createSparkStreamingContext(conf, kafkaConsumerParamMap, otherPropertiesMap) })

    ssc.start
    ssc.awaitTermination
  }
}